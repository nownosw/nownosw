import { appConfig } from './config-main';
import { contracts, assets } from './addresses';

export { appConfig, contracts, assets };
