/* Main app configs go here */
export const appConfig = {
    name: 'Balancer',
    shortName: 'Balancer',
    description: '',
    splashScreenBackground: '#ffffff',
};
